import LoginPages from "../../pages/LoginPage.js";
import InventoryPages from "../../pages/InventoryPage.js"


describe("Login with POM", () => {
  const LoginPages = new LoginPages();
  const InventoryPages = new InventoryPages();

  beforeEach(() => {
    LoginPages.open();
  });

  it("should login with valid credentials", () => {
    LoginPages.login("standard_user", "secret_sauce");
    //перевірили перехід на сторінку
    cy.url("pathname").should("eq", "https://www.saucedemo.com/inventory.html");
    // Переірка що елемент відображається і містить текст Products
    cy.get('[data-test="title"]')
      .should("be.visible")
      .and("have.text", "Products");
    // cy.get('[data-test="title"]').should('have.text' , 'Products')
  });

  it("should login with valid credentials", () => {
    LoginPages.enterUsername("standard_user");
    LoginPages.enterPassword("secret_sauce");
    LoginPages.clickLoginButton();
  });


  it("should login with valid credentials", () => {
    LoginPages.login("standard_user", "secret_sauce");
    InventoryPages.checkPageOpened();


    LoginPages.open();

cy.get('[data-test="username"]')
  .type('standard_user');

LoginPages.enterPassword('secret_sauce');
  });

});
